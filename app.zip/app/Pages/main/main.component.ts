import { Component, OnInit } from '@angular/core';

import { ANIMALS } from '../../DataSource/animals';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  
  constructor() { }

  //ngOnInit() {}


  animals = ANIMALS;
  cols: any[];
  dtOptions = {};
  animalData = {};

  ngOnInit() {
    //can move this data anywhere
    this.dtOptions = {
      cols: [
        { field: 'id', header: "Id" },
        { field: 'type', header: "Type" },
      ],
      data: this.animals
    }

    this.animalData = {
      data: this.animals
    }
  }

  

}
