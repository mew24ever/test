import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { MaterialsModule } from './materials.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './Pages/home/home.component';
import { PageOneComponent } from './Pages/page-one/page-one.component';
import { FormsModule } from '@angular/forms';
import { MenuComponent } from './Modules/menu/menu.component';
import { TransLookupComponent } from './Screens/trans-lookup/trans-lookup.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    PageOneComponent,
    MenuComponent,
    TransLookupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialsModule,
    FormsModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
