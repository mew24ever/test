export class Element {
  id: number;
  name: string;
  atomicNumber: number;
}
