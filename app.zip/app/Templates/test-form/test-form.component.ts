import { Component, OnInit, Input } from '@angular/core';
import { SelectItem } from 'primeng/api';

import { ANIMALS2 } from '../../DataSource/animals';

@Component({
  selector: 'app-test-form',
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.css']
})
export class TestFormComponent implements OnInit {

  testAnimals = ANIMALS2;
  selectedAnimal: any;


  @Input() options = {
    data: []
  }
  constructor() { }

  ngOnInit() {
  }

}
