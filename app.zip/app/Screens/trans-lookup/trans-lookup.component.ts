import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trans-lookup',
  templateUrl: './trans-lookup.component.html',
  styleUrls: ['./trans-lookup.component.css']
})
export class TransLookupComponent implements OnInit {
  //get data
  constructor() { }

  //set data
  ngOnInit() {
  }

  transLookupDisplay: boolean = false;

  showTransLookupDisplay() {
    this.transLookupDisplay = true;
  }



}
