import { Component, OnInit } from '@angular/core';

import { MenuItem } from 'primeng/api';

import { TransLookupComponent } from '../../Screens/trans-lookup/trans-lookup.component';
import { Command } from 'selenium-webdriver';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  items: MenuItem[];

  constructor() { }

  ngOnInit() {
    this.items = [
      {
        label: 'A',
        items: [
          {
            label: 'A'
            //Command: showTransLookupDisplay();
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A',
            items: [
              {
                label: 'A'
              },
              {
                label: 'A'
              },
              {
                label: 'A'
              },
              {
                label: 'A'
              },
              {
                label: 'A'
              },
              {
                label: 'A'
              },
              {
                label: 'A'
              },
              {
                label: 'A'
              },
              {
                label: 'A'
              },
            ]
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A',
            items: [
              {
                label: 'A'
              },
              {
                label: 'A'
              },
            ]
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
      {
        label: 'A',
        items: [
          {
            label: 'A'
          },
          {
            label: 'A'
          },
          {
            label: 'A'
          }
        ]
      },
    ];
  }

}
