import { NgModule } from '@angular/core';

import { PanelMenuModule } from 'primeng/panelmenu';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { TooltipModule } from 'primeng/tooltip';
import { DialogModule } from 'primeng/dialog';

@NgModule({
  declarations: [],
  imports: [
    PanelMenuModule,
    ScrollPanelModule,
    TooltipModule,
    DialogModule
  ],
  exports: [
    PanelMenuModule,
    ScrollPanelModule,
    TooltipModule,
    DialogModule
  ],
  providers: [],
  bootstrap: []
})
export class MaterialsModule { }
