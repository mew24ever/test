import { NgModule } from "@angular/core";
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


/*primeng*/
import { TableModule } from 'primeng/table';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { ToastModule } from 'primeng/toast';
import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { DialogModule } from 'primeng/dialog';

@NgModule({
  imports: [
    
  ],
  exports: [
    CommonModule,
    FormsModule,
    TableModule,
    DynamicDialogModule,
    ToastModule,
    ButtonModule,
    DropdownModule,
    DialogModule
    
  ]
})
export class MaterialsModule {}
