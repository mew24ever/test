import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { MaterialsModule } from './materials.module';
import { MatDialogModule } from "@angular/material";

import { AppComponent } from './app.component';

/*Templates*/
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { DataTableComponent } from './Templates/data-table/data-table.component';
import { TabsComponent } from './Templates/tabs/tabs.component';
import { DialogComponent } from './Templates/dialog/dialog.component';

/*Pages*/
import { LoginComponent } from './Pages/login/login.component';
import { MainComponent } from './Pages/main/main.component';
import { HomeComponent } from './Pages/SubPages/home/home.component';
import { SettingsComponent } from './Pages/SubPages/settings/settings.component';
import { HelpComponent } from './Pages/SubPages/help/help.component';
import { LogoutComponent } from './Pages/SubPages/logout/logout.component';
import { TestFormComponent } from './Templates/test-form/test-form.component';

@NgModule({
  declarations: [
    AppComponent,
    NavigationBarComponent,
    DataTableComponent,
    TabsComponent,
    DialogComponent,
    LoginComponent,
    MainComponent,
    HomeComponent,
    SettingsComponent,
    HelpComponent,
    LogoutComponent,
    TestFormComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MaterialsModule,
    MatDialogModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [
    DialogComponent
  ]
})
export class AppModule { }
