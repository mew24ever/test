import { Component, OnInit, Input } from '@angular/core';
import { SelectItem } from 'primeng/api';

import { ANIMALS } from '../../DataSource/animals';

@Component({
  selector: 'app-test-form',
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.css']
})
export class TestFormComponent implements OnInit {

  testAnimals = ANIMALS;
  selectedAnimal: any;


  @Input() options = {
    data: []
  }
  constructor() { }

  ngOnInit() {
  }

}
