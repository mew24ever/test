import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './Pages/login/login.component';
import { MainComponent } from './Pages/main/main.component';
import { SettingsComponent } from './Pages/SubPages/settings/settings.component';
import { HelpComponent } from './Pages/SubPages/help/help.component';
import { LogoutComponent } from './Pages/SubPages/logout/logout.component';


const routes: Routes = [
  //{
  //  path: '',
  //  redirectTo: '/login',  **put in when login logic and auth is ready
  //  pathMatch: 'full'
  //},
  {
    path: '',
    redirectTo: '/main',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'main',
    component: MainComponent
  },
  {
    path: 'settings',
    component: SettingsComponent
  },
  {
    path: 'help',
    component: HelpComponent
  },
  {
    path: 'logout',
    component: LogoutComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
