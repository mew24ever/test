export class Animal {
  id: number;
  type: string;
}
