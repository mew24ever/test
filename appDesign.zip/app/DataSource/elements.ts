import { Element } from './Containers/element';

export const ELEMENTS: Element[] = [
  { id: 1, name: 'nickle', atomicNumber: 28},
  { id: 2, name: 'Beryllium', atomicNumber: 4},
  { id: 3, name: 'Oxygen', atomicNumber: 8},
  { id: 4, name: 'Hydrogen', atomicNumber: 1},
  { id: 5, name: 'Nitrogen', atomicNumber: 7},
];
