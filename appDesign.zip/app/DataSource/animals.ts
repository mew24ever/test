import { Animal } from './Containers/animal';

export const ANIMALS: Animal[] = [
  {id: 1, type: 'dog'},
  {id: 2, type: 'cat'},
  {id: 3, type: 'bird'},
  {id: 4, type: 'frog'},
  {id: 5, type: 'rat'},
];


export const ANIMALS2 = [
  { value: 1, label: 'dog' },
  { value: 2, label: 'cat' },
  { value: 3, label: 'bird' },
  { value: 4, label: 'frog' },
  { value: 5, label: 'rat' }
];
