import { Component, OnInit } from '@angular/core';

import { ELEMENTS } from '../../../DataSource/elements';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

  elements = ELEMENTS;
  cols: any[];
  dtOptions = {};


  constructor() { }

  ngOnInit() {
    this.dtOptions = {
      cols: [
        { field: 'id', header: "Id" },
        { field: 'name', header: "Name" },
        { field: 'atomicNumber', header: "Atomic Number" },
      ],
      data: this.elements
    }
  }

}
