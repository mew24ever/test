import { Component, OnInit } from '@angular/core';

import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  items: MenuItem[];

  constructor() { }

  ngOnInit() {
    this.items = [
      {
        label: 'Lookup',
        items: [
          {
            label: 'Transaciton lookup',
            icon: ''
          },
          {
            label: 'Pain Claim lookup',
            icon: ''
          },
          {
            label: 'PDE lookup',
            icon: ''
          }
        ]
      },
      {
        label: 'Eligibility',
        items: [
          {
            label:'Member'
          },
          {
            label: 'Rapid member entry'
          },
          {
            label: 'member loader'
          },
          {
            label: 'member entry manager'
          },
          {
            label: 'member query'
          },
          {
            label: 'card printer'
          },
          {
            label: 'file management'
          },
        ]
      },
      {
        label: 'Plan configuration',
        items: [
          {
            label: 'association'
          },
          {
            label: 'organization'
          },
          {
            label: 'carrier'
          },
          {
            label: 'group'
          },
          {
            label: 'plan'
          },
          {
            label: 'subgroups'
          },
          {
            label: 'account manager'
          },
          {
            label: 'location manager'
          },
          {
            label: 'process manager'
          },
          {
            label: 'dependency table'
          },
          {
            label: 'cob object'
          },
          {
            label: 'dur'
          },
          {
            label: 'handlers',
            items: [
              {
                label: 'age'
              },
              {
                label: 'cost'
              },
              {
                label: 'cost lists'
              },
              {
                label: 'copay'
              },
              {
                label: 'dispensing limits'
              },
              {
                label: 'dispensing fee'
              },
              {
                label: 'refill'
              },
              {
                label: 'professional fee'
              },
              {
                label: 'misc fee'
              },
            ]
          },
          {
            label: 'special deduc/cap'
          },
          {
            label: 'quickcodes'
          },
          {
            label: 'transaction messages'
          },
          {
            label: 'imports'
          },
          {
            label: 'group loader'
          },
          {
            label: 'gpl manager'
          },
          {
            label: 'member group account'
          },
          {
            label: 'auto enroll zip codes'
          },
        ]
      },
      {
        label: 'Pharmacy configuration',
        items: [
          {
            label: 'pharmacy'
          },
          {
            label: 'networks'
          },
          {
            label: 'chain'
          }
        ]
      },
      {
        label: 'Claim manipulation',
        items: [
          {
            label: 'claim entry'
          },
          {
            label: 'claim reprocessing'
          },
          {
            label: 'fir testing'
          },
          {
            label: 'rapid claim entry'
          },
          {
            label: 'recoveries manager'
          }
        ]
      },
      {
        label: 'Physician configuration',
        items: [
          {
            label: 'dea'
          },
          {
            label: 'prescriber',
            items: [
              {
                label: 'prescriber screens'
              },
              {
                label: 'prescriber loader'
              },
            ]
          },
          {
            label: 'physician network'
          }
        ]
      },
      {
        label: 'Drug configuration',
        items: [
          {
            label: 'mac manager'
          },
          {
            label: 'formulary manager'
          },
          {
            label: 'drug'
          },
          {
            label: 'drug application type'
          }
        ]
      },
      {
        label: 'Customer service',
        items: [
          {
            label: 'call tracking'
          },
          {
            label: 'prior auth'
          },
          {
            label: 'recvd griev docs'
          },
          {
            label: 'manual claims dashboard'
          }
        ]
      },
      {
        label: 'Administarative functions',
        items: [
          {
            label: 'audit'
          },
          {
            label: 'reporting'
          },
          {
            label: 'mpa manager'
          },
          {
            label: 'benefit adjustments'
          },
          {
            label: 'bin/proc'
          },
          {
            label: 'drug change notification'
          },
          {
            label: 'pcn logic'
          },
          {
            label: 'universal reports'
          },
          {
            label: 'griev template docs'
          },
          {
            label: 'griev reports'
          },
          {
            label: 'mass updates'
          },
        ]
      },
      {
        label: 'Prior Authorization',
        items: [
          {
            label: 'drug manager'
          },
          {
            label: 'document manager'
          },
          {
            label: 'question manager'
          },
          {
            label: 'medical code manager'
          },
          {
            label: 'worklist'
          },
          {
            label: 'configuration'
          },
          {
            label: 'batch prints'
          }
        ]
      },
      {
        label: 'PDE',
        items: [
          {
            label: 'pde fixer'
          },
          {
            label: 'pde writer'
          }
        ]
      },
      {
        label: 'CRE',
        items: [
          {
            label: 'question manager'
          },
          {
            label: 'document editor'
          },
          {
            label: 'drug editor'
          }
        ]
      },
    ];
  }






}
