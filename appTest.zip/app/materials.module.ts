import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { CommonModule } from '@angular/common';

/*primgng*/
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { PanelMenuModule } from 'primeng/panelmenu';

@NgModule({
  declarations: [

  ],
  imports: [
    FormsModule,
    ReactiveFormsModule ,
    CommonModule,
    DialogModule,
    DropdownModule,
    ButtonModule,
    PanelMenuModule
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule ,
    CommonModule,
    DialogModule,
    DropdownModule,
    ButtonModule,
    PanelMenuModule
  ],
  providers: [],
  bootstrap: []
})
export class MaterialsModule { }
