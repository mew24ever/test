import { Component, OnInit } from '@angular/core';


import { AppUser } from '../app-users';
import { AppUserAuth } from '../app-user-auth';
import { SecurityService } from '../security.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //here create variables

  user: AppUser = new AppUser();
  securityObject: AppUserAuth = null;

  constructor(
    private securityService: SecurityService,
    private router: Router
    ) {
    //retrieve data
  }

  ngOnInit() {
    //set variables, runs after constructor that retrieves variable data
  }

  login() {
    this.securityService.login(this.user)
      .subscribe(resp => {
        this.securityObject = resp;
      });

    if (this.securityObject.isAuthenticated) {
      this.router.navigate(['/home'])
    }
  }

}
